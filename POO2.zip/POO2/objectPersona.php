<?php 

include_once('persona.php');

$persona = new Persona('Fernando','Gaitan',30);

echo $persona->saludar();

unset($persona);
