<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <link rel="stylesheet" href="./css/Style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
    <title>Document</title>
</head>

<body>
    <section class="mt-5 mb-5">
        <div>
            <div class="row d-flex justify-content-center align-items-center h-100 bg-dark">
                <div class="col col-xl-10">
                    <div class="row g-0">
                        <div class="col-md-6 col-lg-5 d-none d-md-block bg-dark">
                            <div class="birds card-body p-4 p-lg-5 ms-lg-5">
                                <div class="birds__hatdove">
                                    <div class="birds__hatdove-shadow"></div>
                                    <div class="birds__hatdove-head">
                                        <div class="birds__hatdove-hat"></div>
                                        <div class="birds__hatdove-forehead"></div>
                                        <div class="birds__hatdove-eye"></div>
                                        <div class="birds__hatdove-eye"></div>
                                        <div class="birds__hatdove-beak"></div>
                                    </div>
                                    <div class="birds__hatdove-backwing"></div>
                                    <div class="birds__circles-1"></div>
                                    <div class="birds__hatdove-backleg">
                                        <div class="birds__curly"></div>
                                    </div>
                                    <div class="birds__hatdove-body"></div>
                                    <div class="birds__hatdove-frontleg">
                                        <div class="birds__curly"></div>
                                    </div>
                                    <div class="birds__hatdove-frontwing"></div>
                                    <div class="birds__circles-2"></div>
                                    <div class="birds__hatdove-frontwing-finger"></div>
                                    <div class="birds__hatdove-frontwing-finger"></div>
                                    <div class="birds__hatdove-frontwing-finger"></div>
                                </div>
                                <div class="birds__table">
                                    <div class="birds__table-shadow"></div>
                                </div>
                                <div class="birds__laptop"></div>
                            </div>
                        </div>
                        <div class="col-md-6 col-lg-7 d-flex align-items-center">
                            <div class="card-body p-4 p-lg-5 text-light ms-lg-5">

                                <form>

                                    <div class="d-flex align-items-center mb-3 pb-1">
                                        <i class="fas fa-cubes fa-2x me-3" style="color: #ff6219;"></i>
                                        <span class="h1 fw-bold mb-0">Finance Manager</span>
                                    </div>

                                    <h5 class="fw-normal mb-3 pb-3" style="letter-spacing: 1px;">Sign into your account
                                    </h5>

                                    <div class="form-outline mb-4">
                                        <input type="email" id="form2Example17" class="form-control form-control-lg" />
                                        <label class="form-label" for="form2Example17">Email address</label>
                                    </div>

                                    <div class="form-outline mb-4">
                                        <input type="password" id="form2Example27"
                                            class="form-control form-control-lg" />
                                        <label class="form-label" for="form2Example27">Password</label>
                                    </div>

                                    <div class="pt-1 mb-4">
                                        <button class="btn btn-light btn-lg btn-block" type="button">Login</button>
                                    </div>
                                </form>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        </div>
    </section>
</body>

</html>